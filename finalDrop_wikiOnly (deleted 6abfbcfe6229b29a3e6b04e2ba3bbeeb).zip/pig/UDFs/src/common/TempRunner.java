package common;

public class TempRunner {

	public static void main(String[] args) {
	}

}
